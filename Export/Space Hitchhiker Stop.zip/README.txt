SPACE HITCHIKER STOP
Currently, there's only a costumer, which disappears after 5 seconds (prototype/testing), a button that can be dragged and 4 scene buttons that will be used to navigate through the store!​


Team Mem​bers:
Alexandru191919
​Github
Slack​​
Haster252


How would you pitch your game in one line?
It's like Papers Please, but you're in space and you have a gas station, and you get robbed and space station things stuff happens. 

What is the key mechanic(s) that make it fun?
The game is fun since you are able to do many things in your gas station, you can restock your shelves, attend your costumers, and even shoot armed robbers with your trusy space shotgun!

How does the game actually play?
The goal of the game is trying to make as much profit as you can and avoiding becoming bancrupt. There are upgrades to make your gas stations security and improve profits.

The end achievement of the game will be to survive as most days as possible, until you can retire. Once the end goal is met, you're able to play the game indefinitely!!

How will you keep players engaged for 30 minutes? What's the general scope of your game (will change as you go)?
The desire of upgrading your station and maximising your profits will hook the players into completing it, the mini-events (such as costumers needing help, robbers trying to avoid the payment...) will keep the gameplay fresh and pretty replayable.

---

All content in the description is our main idea of how the ended game would be like, everything written here is subject to change in the final game.